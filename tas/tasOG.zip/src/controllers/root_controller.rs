use iced::Task;

use crate::app::{AppState, Message, WorkspaceMessage};
use crate::db::Database;
use crate::state::{DbAction, ToastKind};
use crate::controllers::{pm_controller, bestiary_controller, universe_controller, locations_controller, timeline_controller, the_forge_controller};
use crate::project_manager::ProjectManager;
use crate::Message as MainMessage;

pub fn update(state: &mut AppState, message: Message) {
    match message {
        Message::Navigate(route) => state.route = route,
        Message::BackToUniverses => state.route = crate::app::Route::UniverseList,
        Message::BackToUniverse(id) => state.route = crate::app::Route::UniverseDetail { universe_id: id },
        Message::OpenTimeline(id) => state.route = crate::app::Route::Timeline { universe_id: id },

        Message::GoToLocation(universe_id, location_id) => {
            state.route = crate::app::Route::Locations { universe_id };
            state.selected_location = Some(location_id.clone());

            // Auto-expand tree to find the location
            let mut current_search = Some(location_id);
            let mut safeguard = 0;
            while let Some(curr_id) = current_search {
                if safeguard > 50 { break; } // Prevent infinite loops
                safeguard += 1;

                if let Some(loc) = state.locations.iter().find(|l| l.id == curr_id) {
                    if let Some(parent_id) = &loc.parent_id {
                        state.expanded_locations.insert(parent_id.clone());
                        current_search = Some(parent_id.clone());
                    } else {
                        current_search = None;
                    }
                } else {
                    current_search = None;
                }
            }
        }

        Message::Workspace(msg) => match msg {
            WorkspaceMessage::CreateStart => { state.is_creating_project = true; state.new_project_name.clear(); }
            WorkspaceMessage::CreateCancel => state.is_creating_project = false,
            WorkspaceMessage::NameChanged(v) => state.new_project_name = v,
            _ => {}
        },

        Message::ProjectsLoaded(projs) => state.projects = projs,

        // Delegate module-specific messages
        Message::Pm(msg) => pm_controller::update(state, msg),
        Message::Bestiary(msg) => bestiary_controller::update(state, msg),
        Message::Universe(msg) => universe_controller::update(state, msg),
        Message::Locations(msg) => locations_controller::update(state, msg),
        Message::Timeline(msg) => timeline_controller::update(state, msg),
        Message::TheForge(msg) => the_forge_controller::update(state, msg), // <--- WIRED

        // Global Mouse Events (Delegated to PM Controller for Drag&Drop)
        Message::MouseMoved(p) => {
            pm_controller::handle_mouse_moved(state, p);
        }

        Message::MouseReleased => {
            pm_controller::handle_mouse_released(state);
        }

        // Results handling
        Message::UniversesFetched(Ok(v)) => state.universes = v,
        Message::BoardsFetched(Ok(v)) => state.boards_list = v,
        Message::PmBoardFetched(Ok(v)) => state.pm_data = Some(v),

        Message::CreaturesFetched(Ok(v)) => {
            state.creatures = v;
            if let crate::app::Route::Bestiary { universe_id } = &state.route {
                state.loaded_creatures_universe = Some(universe_id.clone());
            }
        }

        Message::LocationsFetched(Ok(v)) => {
            state.locations = v;
            if let crate::app::Route::Locations { universe_id } = &state.route {
                state.loaded_locations_universe = Some(universe_id.clone());
            }
        }

        Message::TimelineFetched(Ok((events, eras))) => {
            state.timeline_events = events;
            state.timeline_eras = eras;
            if let crate::app::Route::Timeline { universe_id } = &state.route {
                state.loaded_timeline_universe = Some(universe_id.clone());
            }
        }

        // --- THE FORGE RESULTS ---
        Message::StoriesFetched(Ok(v)) => state.stories = v,
        Message::ScenesFetched(Ok(v)) => state.active_story_scenes = v,

        Message::SnapshotsFetched(Ok(v)) => state.snapshots = v,
        Message::SchemaVersionFetched(Ok(v)) => state.debug_schema_version = Some(v),
        Message::IntegrityFetched(Ok(v)) => {
            state.integrity_issues = v;
            state.integrity_busy = false;
        }

        // Errors
        Message::UniversesFetched(Err(e))
        | Message::BoardsFetched(Err(e))
        | Message::PmBoardFetched(Err(e))
        | Message::CreaturesFetched(Err(e))
        | Message::LocationsFetched(Err(e))
        | Message::TimelineFetched(Err(e))
        | Message::SnapshotsFetched(Err(e))
        | Message::SchemaVersionFetched(Err(e))
        | Message::IntegrityFetched(Err(e))
        | Message::StoriesFetched(Err(e))
        | Message::ScenesFetched(Err(e)) => {
            state.show_toast(format!("Error loading data: {}", e), ToastKind::Error);
            state.integrity_busy = false;
        }

        Message::Tick(_) => {
            let now = std::time::Instant::now();
            state.toasts.retain(|t| now.duration_since(t.created_at).as_secs() < t.ttl_secs);
        }

        Message::ToastDismiss(id) => state.toasts.retain(|t| t.id != id),

        _ => {}
    }
}

pub fn post_event_tasks(state: &mut AppState, db: &Option<Database>) -> Vec<Task<MainMessage>> {
    let mut tasks = Vec::new();
    let Some(db_base) = db else { return tasks };

    // Keep projects fresh in launcher-ish contexts
    if state.projects.is_empty() {
        tasks.push(Task::perform(async { ProjectManager::load_projects() }, MainMessage::ProjectsLoaded));
    }

    // 1) Process DB queue (ONE at a time to ensure order and avoid locks)
    if state.db_inflight.is_none() {
        if let Some(action) = state.db_queue.pop_front() {
            state.db_inflight = Some(action.clone());
            let db = db_base.clone();

            tasks.push(Task::perform(
                async move {
                    match action {
                        DbAction::CreateUniverse(n, d) => db.create_universe(n, d).await.map_err(|e| e.to_string()),
                        DbAction::DeleteUniverse(id) => db.delete_universe(id).await.map_err(|e| e.to_string()),
                        DbAction::InjectDemoData(id) => db.inject_demo_data(id).await.map_err(|e| e.to_string()),
                        DbAction::ResetDemoDataScoped(id, scope) => db.reset_demo_data_scoped(id, scope).await.map_err(|e| e.to_string()),

                        DbAction::SnapshotCreate { universe_id, name } => db.snapshot_create(universe_id, name).await.map_err(|e| e.to_string()),
                        DbAction::SnapshotDelete { snapshot_id } => db.snapshot_delete(snapshot_id).await.map_err(|e| e.to_string()),
                        DbAction::SnapshotRestore { snapshot_id } => db.snapshot_restore(snapshot_id).await.map(|_| ()).map_err(|e| e.to_string()),

                        DbAction::CreateBoard(n) => db.create_board(n).await.map_err(|e| e.to_string()),
                        DbAction::DeleteBoard(id) => db.delete_board(id).await.map_err(|e| e.to_string()),

                        DbAction::SaveCreature(c, uid) => db.upsert_creature(c, uid).await.map_err(|e| e.to_string()),
                        DbAction::ArchiveCreature(id, st) => db.set_creature_archived(id, st).await.map_err(|e| e.to_string()),
                        DbAction::DeleteCreature(id) => db.delete_creature(id).await.map_err(|e| e.to_string()),

                        DbAction::SaveLocation(l) => db.upsert_location(l).await.map_err(|e| e.to_string()),
                        DbAction::DeleteLocation(id) => db.delete_location(id).await.map_err(|e| e.to_string()),

                        DbAction::SaveEvent(e) => db.upsert_timeline_event(e).await.map_err(|e| e.to_string()),
                        DbAction::DeleteEvent(id) => db.delete_timeline_event(id).await.map_err(|e| e.to_string()),
                        DbAction::SaveEra(e) => db.upsert_timeline_era(e).await.map_err(|e| e.to_string()),
                        DbAction::DeleteEra(id) => db.delete_timeline_era(id).await.map_err(|e| e.to_string()),

                        DbAction::SaveCard(c) => db.upsert_card(c).await.map_err(|e| e.to_string()),
                        DbAction::MoveCard(cid, col, pos) => db.move_card(cid, col, pos).await.map_err(|e| e.to_string()),
                        DbAction::RebalanceColumn(col) => db.rebalance_column(col).await.map_err(|e| e.to_string()),
                        DbAction::DeleteCard(id) => db.delete_card(id).await.map_err(|e| e.to_string()),

                        // --- THE FORGE ACTIONS ---
                        DbAction::CreateStory(uid, title) => db.create_story(uid, title).await.map_err(|e| e.to_string()),
                        DbAction::UpdateStory(s) => db.upsert_story(s).await.map_err(|e| e.to_string()),
                        DbAction::DeleteStory(id) => db.delete_story(id).await.map_err(|e| e.to_string()),
                        DbAction::CreateScene(sid, title) => db.create_scene(sid, title).await.map_err(|e| e.to_string()),
                        DbAction::UpdateScene(s) => db.upsert_scene(s).await.map_err(|e| e.to_string()),
                        DbAction::DeleteScene(id) => db.delete_scene(id).await.map_err(|e| e.to_string()),
                        DbAction::ReorderScene(_, _) => Ok(()), // TODO: Implement logic if needed
                    }
                },
                MainMessage::ActionDone,
            ));
        }
    }

    // 2) Lazy fetch for current route (Smart Polling)
    if state.db_inflight.is_none() {
        match &state.route {
            crate::app::Route::UniverseList => {
                let db = db_base.clone();
                tasks.push(Task::perform(async move { db.get_all_universes().await.map_err(|e| e.to_string()) }, MainMessage::UniversesFetched));
            }

            crate::app::Route::PmList => {
                let db = db_base.clone();
                tasks.push(Task::perform(async move { db.get_all_boards().await.map_err(|e| e.to_string()) }, MainMessage::BoardsFetched));
            }

            crate::app::Route::PmBoard { board_id } => {
                // Only refetch if board changed or we have no data
                let need_fetch = state.pm_data.as_ref().map(|d| d.board.id != *board_id).unwrap_or(true);
                if need_fetch {
                    let db = db_base.clone();
                    let bid = board_id.clone();
                    tasks.push(Task::perform(async move { db.get_kanban_data(bid).await.map_err(|e| e.to_string()) }, MainMessage::PmBoardFetched));
                }
            }

            crate::app::Route::Bestiary { universe_id } => {
                if state.loaded_creatures_universe.as_ref() != Some(universe_id) {
                    let db = db_base.clone();
                    let uid = universe_id.clone();
                    tasks.push(Task::perform(async move { db.get_creatures(uid).await.map_err(|e| e.to_string()) }, MainMessage::CreaturesFetched));
                }
                // Locations needed for dropdowns
                let db = db_base.clone();
                let uid = universe_id.clone();
                tasks.push(Task::perform(async move { db.get_locations_flat(uid).await.map_err(|e| e.to_string()) }, MainMessage::LocationsFetched));
            }

            crate::app::Route::Locations { universe_id } => {
                if state.loaded_locations_universe.as_ref() != Some(universe_id) {
                    let db = db_base.clone();
                    let uid = universe_id.clone();
                    tasks.push(Task::perform(async move { db.get_locations_flat(uid).await.map_err(|e| e.to_string()) }, MainMessage::LocationsFetched));
                }
            }

            crate::app::Route::Timeline { universe_id } => {
                if state.loaded_timeline_universe.as_ref() != Some(universe_id) {
                    let db = db_base.clone();
                    let uid = universe_id.clone();
                    tasks.push(Task::perform(async move {
                        let events = db.get_timeline_events(uid.clone()).await.map_err(|e| e.to_string())?;
                        let eras = db.get_timeline_eras(uid).await.map_err(|e| e.to_string())?;
                        Ok((events, eras))
                    }, MainMessage::TimelineFetched));
                }
                // Locations needed for event editor dropdowns
                let db = db_base.clone();
                let uid = universe_id.clone();
                tasks.push(Task::perform(async move { db.get_locations_flat(uid).await.map_err(|e| e.to_string()) }, MainMessage::LocationsFetched));
            }

            // --- THE FORGE FETCHING ---
            crate::app::Route::Forge => {
                // Como Forge no tiene ID en la ruta (es global al workspace o requiere selección),
                // asumimos que el usuario DEBE seleccionar un universo primero.
                // Pero en tu App, Forge es un módulo global en la sidebar.
                // ESTRATEGIA: Si vienes de un Universo, state.loaded_forge_universe debería setearse.
                // Si está vacío, la UI mostrará "Select Universe".

                if let Some(uid) = &state.loaded_forge_universe {
                    let db = db_base.clone();
                    let u = uid.clone();
                    tasks.push(Task::perform(async move { db.get_stories(u).await.map_err(|e| e.to_string()) }, MainMessage::StoriesFetched));

                    if let Some(sid) = &state.active_story_id {
                        let db2 = db_base.clone();
                        let s = sid.clone();
                        tasks.push(Task::perform(async move { db2.get_scenes(s).await.map_err(|e| e.to_string()) }, MainMessage::ScenesFetched));
                    }
                }
            }

            crate::app::Route::UniverseDetail { universe_id } => {
                // schema version check
                if state.debug_overlay_open && state.debug_schema_version.is_none() {
                    let db = db_base.clone();
                    tasks.push(Task::perform(async move { db.get_schema_version().await.map_err(|e| e.to_string()) }, MainMessage::SchemaVersionFetched));
                }

                // snapshot list fetching
                if state.loaded_snapshots_universe.as_ref() != Some(universe_id) {
                    let db = db_base.clone();
                    let uid = universe_id.clone();
                    tasks.push(Task::perform(async move { db.snapshot_list(uid).await.map_err(|e| e.to_string()) }, MainMessage::SnapshotsFetched));
                    state.loaded_snapshots_universe = Some(universe_id.clone());
                }

                // integrity check trigger
                if state.integrity_busy {
                    let db = db_base.clone();
                    let uid = universe_id.clone();
                    tasks.push(Task::perform(async move { db.validate_universe(uid).await.map_err(|e| e.to_string()) }, MainMessage::IntegrityFetched));
                }

                // Pre-load Forge Universe context
                state.loaded_forge_universe = Some(universe_id.clone());
            }

            _ => {}
        }
    }

    tasks
}
