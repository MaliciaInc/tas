use iced::{Alignment, Length};
use iced::widget::{container, text, Column, Row};

use crate::app::{AppState, Message, Route, BestiaryMessage, LocationsMessage, UniverseMessage};
use crate::{ui, pages::E};

pub fn universe_detail<'a>(state: &'a AppState, t: ui::Tokens, universe_id: &'a str) -> E<'a> {
    let u = state.universes.iter().find(|x| x.id == universe_id);

    let (name, desc) = match u {
        Some(u) => (u.name.clone(), u.description.clone()),
        None => ("Unknown".to_string(), "".to_string()),
    };

    let header_left = Column::new()
        .spacing(4)
        .push(text(name.clone()).size(26).color(t.foreground))
        .push(text(desc).size(12).color(t.muted_fg))
        .push(text("Status: Active").size(12).color(t.muted_fg));

    let header_right = Row::new()
        .spacing(10)
        .push(ui::outline_button(t, "Back to universes".to_string(), Message::BackToUniverses))
        .push(ui::outline_button(t, "Go to PM Tools".to_string(), Message::Navigate(Route::PmList)));

    let header = Row::new()
        .align_y(Alignment::Center)
        .push(container(header_left).width(Length::Fill))
        .push(header_right);

    let summary = Column::new()
        .spacing(8)
        .push(text("About this universe").size(12).color(t.muted_fg))
        .push(
            ui::card(
                t,
                Column::new()
                    .spacing(6)
                    .push(text("• Contains custom laws of physics and magic systems.").size(12).color(t.muted_fg))
                    .push(text("• Home to specific species in bestiary, artifacts, etc.").size(12).color(t.muted_fg))
                    .push(text("• Quick links to PM boards, documents and assets related to this universe.").size(12).color(t.muted_fg))
                    .into(),
            )
        );

    let tools = Column::new()
        .spacing(8)
        .push(text("Universe tools").size(12).color(t.muted_fg))
        .push(
            Row::new()
                .spacing(10)
                .push(ui::outline_button(t, "Bestiary".to_string(), Message::Bestiary(BestiaryMessage::Open(universe_id.to_string()))))
                .push(ui::outline_button(t, "Locations".to_string(), Message::Locations(LocationsMessage::Open(universe_id.to_string()))))
                .push(ui::outline_button(t, "Timeline".to_string(), Message::OpenTimeline(universe_id.to_string())))
        );

    let is_pending_reset = state.pending_demo_reset_universe.as_deref() == Some(universe_id);

    let mut debug_row = Row::new()
        .spacing(10)
        .push(ui::primary_button(
            t,
            "Inject Demo Data".to_string(),
            Message::Universe(UniverseMessage::InjectDemoData(universe_id.to_string())),
        ))
        .push(ui::danger_button(
            t,
            "Reset Demo Data".to_string(),
            Message::Universe(UniverseMessage::ResetDemoDataPrompt(universe_id.to_string())),
        ));

    if is_pending_reset {
        debug_row = debug_row
            .push(ui::outline_button(
                t,
                "Cancel".to_string(),
                Message::Universe(UniverseMessage::ResetDemoDataCancel),
            ))
            .push(ui::primary_button(
                t,
                "Confirm Reset".to_string(),
                Message::Universe(UniverseMessage::ResetDemoDataConfirm),
            ));
    }

    let debug_zone = Column::new()
        .spacing(8)
        .push(text("Developer Options").size(12).color(t.muted_fg))
        .push(debug_row);

    let body = Column::new()
        .spacing(20)
        .push(header)
        .push(ui::h_divider(t))
        .push(tools)
        .push(summary)
        .push(ui::h_divider(t))
        .push(debug_zone)
        .width(Length::Fill);

    ui::page_padding(body.into())
}
